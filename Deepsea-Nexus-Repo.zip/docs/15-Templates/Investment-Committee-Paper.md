# Investment-Committee-Paper
